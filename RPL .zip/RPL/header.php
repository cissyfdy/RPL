

<nav class="navbar navbar-expand bg-dark sticky-top">
  <div class="container-lg">
    <a class="navbar-brand text-white" href="#">Die Gaststätte</a>

    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ">
        <li class="nav-item">
          <a class="nav-link text-white" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="lainnya.php">Lainnya</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="#">GAK TAU APAAN</a>
        </li>
</div>

        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
        <ul class="navbar-nav">
        <li class="nav-item">
        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle text-white " href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            ADMIN
          </a>

      <ul class="dropdown-menu dropdown-menu-end mt-3">
            <li><a class="dropdown-item" href="#">Profile</a></li>
            <li><a class="dropdown-item" href="#">Setting</a></li>
            <li><a class="dropdown-item" href="logout">Log out</a></li>




          </ul>
        </li>
      </ul>
    </div>
  </div>  
</nav>