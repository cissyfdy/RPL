



<?php

if (isset($_GET['x']) && $_GET['x']=='Menu') {
      include "main.php";
}elseif(isset($_GET['x']) && $_GET['x']=='Order') {
  include "main.php";
}elseif(isset($_GET['x']) && $_GET['x']=='Customer') {
  include "main.php";
}elseif(isset($_GET['x']) && $_GET['x']=='1') {
  include "main.php";
}elseif(isset($_GET['x']) && $_GET['x']=='2') {
  include "main.php";
}elseif {
  include "login.pho";
}else {
    include "main.php"
}
?>

