<?php 
    $conn = mysqli_connect('localhost', 'root', '', 'rpl');
    if(!$conn){
        // Jika koneksi gagal
        echo 'Gagal terhubung ke database: ' . mysqli_connect_error();
    } else {
        // Jika koneksi berhasil
        echo 'Berhasil terhubung ke database';
    }
?>
